import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";

import { RouterModule } from "@angular/router";
import { BsDropdownModule } from "ngx-bootstrap";
import { ToastrModule } from "ngx-toastr";
import { TagInputModule } from "ngx-chips";
import { CollapseModule } from 'ngx-bootstrap/collapse';


import { AppComponent } from "./app.component";
import { AdminLayoutComponent } from "./layouts/admin-layout/admin-layout.component";
import { AuthLayoutComponent } from "./layouts/auth-layout/auth-layout.component";
import { OverviewLayoutComponent} from "./layouts/overview-layout/overview-layout.component"

import { AppRoutingModule } from "./app-routing.module";
import { ComponentsModule } from "./components/components.module";
import { ComponentsOverviewModule } from "./components-overview/components-overview.module"
import { NgxSpinnerModule } from "ngx-spinner";
import { AuthService } from './auth-strategy/auth.service'
import { from } from 'rxjs';
import { AuthGuard } from './auth-strategy/auth.guard';

// Apollo setup START
import { ApolloModule, APOLLO_OPTIONS } from "apollo-angular";
import { HttpLinkModule, HttpLink } from "apollo-angular-link-http";
import { InMemoryCache } from "apollo-cache-inmemory";
// Apollo setup END
import { MyserviceService } from './myservice.service';
import { IndexsModule } from './pages/index/indexs.module';
import { AuthInterceptor } from './auth-strategy/auth-interceptor';
import { SocketService } from './socket/socket.service'


@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ComponentsModule,
    ComponentsOverviewModule,
    RouterModule,
    BsDropdownModule.forRoot(),
    AppRoutingModule,
    ToastrModule.forRoot(),
    CollapseModule.forRoot(),
    TagInputModule,
    NgxSpinnerModule,
    IndexsModule
    
  ],
  declarations: [AppComponent, AdminLayoutComponent, AuthLayoutComponent, OverviewLayoutComponent ],
  providers: [
    AuthService,
    MyserviceService,
     AuthGuard,
     SocketService,
     {provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true}
    ],
  bootstrap: [AppComponent]
})
export class AppModule {}

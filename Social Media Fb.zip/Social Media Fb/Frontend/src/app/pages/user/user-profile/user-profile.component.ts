import { AfterViewInit, Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Service } from 'src/app/services/service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit, AfterViewInit {
  name: any;
  email: any;
  constructor(public route: ActivatedRoute, private service: Service) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(paramMap => {
      if(paramMap.has('userId')){
        let usersID = paramMap.get('userId');
       let loginID = localStorage.getItem('userId');
       if(loginID == usersID)
        return;
        this.service.user(usersID).subscribe(res => {
          this.name = res.user.name;
          this.email = res.user.email
        })
      }
    })
  }

  ngAfterViewInit(){
    
  }

}

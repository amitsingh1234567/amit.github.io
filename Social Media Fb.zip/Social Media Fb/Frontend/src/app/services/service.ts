import { Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Subject, throwError, Observable, of } from "rxjs";
import { Router } from "@angular/router";
import { ErrorService } from "../error/error-service";


@Injectable({ providedIn: "root" })

export class Service {
    userId = new Subject<any>();
    postData = new Subject<any>();
    private token: string;
    constructor(private http: HttpClient, private router: Router, private errorService: ErrorService){ };

    getToken(){
      return this.token;
    }

    getPostData(){
      return this.postData;
    }

    setPostData(data: any){
      console.log(data)
      this.postData.next(data);
    }

    getUser(){
      return this.userId
    }

    signIn(userCrediantial: Object){
      this.http.post<{success: boolean, token: string, user: any, message: string}>('http://localhost:3000/api/v1/auth/signIn', userCrediantial)
      .subscribe(res => {
        if(res.success){
          this.errorService.throwError(res.message);
          const Token = res.token;
          console.log(Token)
          this.token = Token;
          localStorage.setItem('token', res.token);
          // localStorage.setItem('expiration', expirationDate.toISOString());
          localStorage.setItem('userId', res.user._id);
          this.userId.next(res.user);
        }else{
          this.errorService.throwError(res.message);
        }
      })
    };

    signUp(user: Object){
      return  this.http.post<{success: boolean, user: Object, message: string}>('http://localhost:3000/api/v1/auth/signup', user)
    }

    user(userId){
      return  this.http.get<{success: boolean, user: any}>(`http://localhost:3000/api/v1/user/${userId}`);
    }

    users(){
      return  this.http.get<{success: boolean, data: any}>('http://localhost:3000/api/v1/user/allUsers');
    }

    uploadPost(title: string, image: File, userId: string, uploadType: string){
      const postData = new FormData();
      postData.append('userId', userId);
      postData.append('title', title);
      postData.append('uploadType', uploadType);
      postData.append('images', image);
      return this.http.post<{success: boolean, message: string, data: any}>('http://localhost:3000/api/v1/post/uploadPost', postData);
    }

    uploadProfilePicture(image: File, userId: string, uploadType: string){
      const uploadData = new FormData();
      uploadData.append('userId', userId);
      uploadData.append('uploadType', uploadType);
      uploadData.append('images', image);
      return this.http.post<{success: boolean, message: string, data: any}>('http://localhost:3000/api/v1/post/uploadProfilePicture',uploadData);
    }

    getPosts(pageNo: number, limit: number){
      const queryParams = `?page=${pageNo}&size=${limit}`;
      return  this.http.get<{success: boolean, totalItems: number, msg: string, data: any}>('http://localhost:3000/api/v1/post/allPosts' + queryParams);
    }

    like(postId: string, userId: string){
      let obj = {postId, userId}
      return  this.http.put<{success: boolean, data: any, msg: string}>('http://localhost:3000/api/v1/post/like', obj);
    }

    unLike(postId: string, userId: string){
      let obj = {postId, userId}
      return  this.http.put<{success: boolean, data: any, msg: string}>('http://localhost:3000/api/v1/post/unlike', obj);
    }

    comment(postId: string, commentedBy: string, text: string){
      let obj = {postId, commentedBy, text};
      return  this.http.put<{success: boolean, postId: string, data: any, msg: string}>('http://localhost:3000/api/v1/post/comment', obj);
    }

    commentReply(postId: string, commentId: string, replyedBy: string, text: string, replyToUserName: string){
      let obj = { postId, commentId, replyedBy, text, replyToUserName };
      return  this.http.put<{success: boolean, postId: string, data: any, msg: string}>('http://localhost:3000/api/v1/post/commentReply', obj);
    }


    
}
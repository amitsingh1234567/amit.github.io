import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
// import { ComponentsModule } from "../../components/components.module";
import { ComponentsOverviewModule } from "../../components-overview/components-overview.module"
import { FormsModule } from "@angular/forms";
import { BsDropdownModule } from "ngx-bootstrap";


import { NgxDatatableModule } from "@swimlane/ngx-datatable";
import { NgxPrintModule } from "ngx-print";

import { OverviewComponent } from "./overview/overview.component"
import { RouterModule } from "@angular/router";
import { OverviewsRoutes } from "./overviews.routing"


import { AuthGuard } from '../../auth-strategy/auth.guard';

@NgModule({
  declarations: [ OverviewComponent ],
  imports: [
    CommonModule,
    ComponentsOverviewModule,
    RouterModule.forChild(OverviewsRoutes),
    NgxDatatableModule,
    NgxPrintModule,
    BsDropdownModule
  ],
  exports: [ OverviewComponent ],
  providers: [ AuthGuard ],
})
export class OverviewsModule { }

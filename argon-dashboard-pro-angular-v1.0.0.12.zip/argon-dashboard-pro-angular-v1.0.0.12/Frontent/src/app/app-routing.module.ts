import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";

import { AdminLayoutComponent } from "./layouts/admin-layout/admin-layout.component";
import { AuthLayoutComponent } from "./layouts/auth-layout/auth-layout.component";
import { OverviewLayoutComponent } from "./layouts/overview-layout/overview-layout.component"
const routes: Routes = [
  {
    path: "",
    redirectTo: "indexs/login",
    pathMatch: "full"
  },  
  { 
    path: "",
    component: AdminLayoutComponent,
    children: [
      {
        path: ":id",
        loadChildren: "./pages/plants/plants.module#PlantsModule"
      },       
    ]
  },
  { 
    path: "",
    component: OverviewLayoutComponent,
    children: [
      {
        path: "overviews",
        loadChildren: "./pages/overviews/overviews.module#OverviewsModule"
      },       
    ]
  },
  {
    path: "",
    component: AuthLayoutComponent,
    children: [
      {
        path: "indexs",
        loadChildren:
          "./layouts/auth-layout/auth-layout.module#AuthLayoutModule"
      }
    ]
  },
  {
    path: "**",
    redirectTo: "dashboard"
  }
];

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(routes, {
      useHash: true
    })
  ],
  exports: [RouterModule]
})

export class AppRoutingModule {
  
}

import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
import { AuthService } from 'src/app/auth-strategy/auth.service';
import { MyserviceService } from 'src/app/myservice.service';


var misc: any = {
  sidebar_mini_active: true,
};

export interface RouteInfo {
  path: string;
  title: string;
  type: string;
  icontype: string;
  collapse?: string;
  isCollapsed?: boolean;
  isCollapsing?: any;
  children?: ChildrenItems[];

}

export interface ChildrenItems {
  path: string;
  title: string;
  type?: string;
  collapse?: string;
  children?: ChildrenItems2[];
  isCollapsed?: boolean;
  flag?: any;
  
}
export interface ChildrenItems2 {
  path?: string;
  title?: string;
  type?: string;
}

//Menu Items
 export const ROUTES: RouteInfo[] = [
  {
    path: "/overviews",
    title: "Overview",
    type: "subj",
    icontype: "ni-shop text-primary",
  },

  {
   
    path: '/:id',
    title:"",
    type: "sub",
    icontype: "ni-shop text-primary",
    isCollapsed: true,
    children: [
      { path: "dashboard", title: "Dashboard", type: "link"  },
      { path: "analytics", title: "Analytics", type: "link" },
      { path: "meter", title: "Meter", type: "link" },
      { path: "inverter", title: "Inverter", type: "link" },
      { path: "wms", title: "WMS", type: "link" },
      { path: "alarm", title: "Alarm", type: "link" },
      { path: "data-export", title: "Data Export", type: "link" }, 
      { path: "information", title: "Information", type: "link" },        
    ]
  },
  
];


@Component({
  selector: "app-sidebar",
  templateUrl: "./sidebar.component.html",
  styleUrls: ["./sidebar.component.scss"]
})
export class SidebarComponent implements OnInit {
  public menuItems: any[];
  public isCollapsed = true;
  public routerID: any;
  public plantname = '';
  private flag: any;
  public isTrue = false;

  constructor( private router: Router, private _authService: AuthService, private _myService: MyserviceService) {}

  ngOnInit() {

  console.log('From Sidebar');

  var id = this._myService.getPlantId();
  

  this._myService.plantName(id.params.id).subscribe(async data =>  {
          
    this.plantname = await data.plantName;
    this.flag = await data.flag
    ROUTES[1].children[0].flag = this.flag.dashboard;
    ROUTES[1].children[1].flag = this.flag.analytic;
    ROUTES[1].children[2].flag = this.flag.meter;
    ROUTES[1].children[3].flag = this.flag.inverter;
    ROUTES[1].children[4].flag = this.flag.wms;
    ROUTES[1].children[5].flag = this.flag.alarm;
    ROUTES[1].children[6].flag = this.flag.dataExport;
    this.menuItems = ROUTES.filter(menuItem => menuItem);
  })
    
    this.router.events.subscribe(event => {
      this.isCollapsed = true;
    });
   
   this.routerID = this._authService.getrouterId();
   if(this.routerID !== undefined){
    localStorage.setItem('onClick-Id', this.routerID);
    var routerId = localStorage.getItem('onClick-Id')
    this.routerID = routerId;
    
  }else{
    var routerId = localStorage.getItem('onClick-Id')
    this.routerID = routerId;
  }  
  }


  onClick(id, routes){
    this.router.navigate([`/${id}/${routes}`])
    
  }

  onMouseEnterSidenav() {
    if (!document.body.classList.contains("g-sidenav-pinned")) {
      document.body.classList.add("g-sidenav-show");
    }
  }
  onMouseLeaveSidenav() {
    if (!document.body.classList.contains("g-sidenav-pinned")) {
      document.body.classList.remove("g-sidenav-show");
    }
  }
  minimizeSidebar() {
    const sidenavToggler = document.getElementsByClassName(
      "sidenav-toggler"
    )[0];
    const body = document.getElementsByTagName("body")[0];
    if (body.classList.contains("g-sidenav-pinned")) {
      misc.sidebar_mini_active = true;
    } else {
      misc.sidebar_mini_active = false;
    }
    if (misc.sidebar_mini_active === true) {
      body.classList.remove("g-sidenav-pinned");
      body.classList.add("g-sidenav-hidden");
      sidenavToggler.classList.remove("active");
      misc.sidebar_mini_active = false;
    } else {
      body.classList.add("g-sidenav-pinned");
      body.classList.remove("g-sidenav-hidden");
      sidenavToggler.classList.add("active");
      misc.sidebar_mini_active = true;
    }
  }

}


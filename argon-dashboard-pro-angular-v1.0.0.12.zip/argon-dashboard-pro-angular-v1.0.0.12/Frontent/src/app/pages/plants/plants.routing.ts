import { Routes } from "@angular/router";

import { DashboardComponent } from "./dashboard/dashboard.component";
import { AlarmComponent} from "./alarm/alarm.component";
import { InverterComponent } from './inverter/inverter.component';
import { WmsComponent } from './wms/wms.component';
import { InformationComponent } from './information/information.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { DataExportComponent } from './data-export/data-export.component';
import { MeterComponent } from './meter/meter.component';
import { from } from 'rxjs';
import { AuthGuard } from 'src/app/auth-strategy/auth.guard';

export const PlantsRoutes: Routes = [
  {
    path: "",
    children: [
      {
        path: "dashboard",
        data:{value:false},
        component: DashboardComponent,
        canActivate:[AuthGuard]
      }
    ]
  },
  {
    path: "",
    children: [
      {
        path: "inverter",
        data:{value:false},
        component: InverterComponent,
        canActivate:[AuthGuard]
      }
    ]
  },
  {
    path: "",
    children: [
      {
        path: "alarm",
        data:{value:false},
        component: AlarmComponent,
        canActivate:[AuthGuard]
      }
    ]
  },
  {
    path: "",
    children: [
      {
        path: "wms",
        data:{value:false},
        component: WmsComponent,
        canActivate:[AuthGuard]
      }
    ]
  },
  {
    path: "",
    children: [
      {
        path: "information",
        data:{value:false},
        component: InformationComponent,
        canActivate:[AuthGuard]
      }
    ]
  },
  {
    path: "",
    children: [
      {
        path: "analytics",
        data:{value:false},
        component: AnalyticsComponent,
        canActivate:[AuthGuard]
      }
    ]
  },
  {
    path: "",
    children: [
      {
        path: "data-export",
        data:{value:false},
        component: DataExportComponent,
        canActivate:[AuthGuard]
      }
    ]
  },
  {
    path: "",
    children: [
      {
        path: "meter",
        data:{value:false},
        component: MeterComponent,
        canActivate:[AuthGuard]
      }
    ]
  } 
];

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { CommonModule } from '@angular/common';
import { NavbarComponent} from './navbar/navbar.component'
import { RouterModule } from '@angular/router';
import { MaterialModule } from '../material/material.module'

const component = [NavbarComponent];

@NgModule({
  declarations: component,
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    BrowserModule,
    RouterModule,
    MaterialModule,
  ],
  exports: component,
})

export class ComponentModule { }

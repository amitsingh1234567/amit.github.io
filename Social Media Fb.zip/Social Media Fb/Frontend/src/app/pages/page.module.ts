import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MaterialModule } from '../material/material.module';

import { AllUsersComponent } from './all-users/all-users.component';
import { HomeComponent } from './home/home.component';
import { BoldSpanPipe }from './home/bold-span.pipe';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { UploadPostComponent } from './upload-post/upload-post.component'

const components = [AllUsersComponent, HomeComponent, BoldSpanPipe, UploadPostComponent];

@NgModule({
  declarations: components,
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    PaginationModule,
    ReactiveFormsModule
    // RouterModule.forChild(PageRoutes)
  ],
  exports: components,
  entryComponents: [UploadPostComponent],
  providers: []
})

export class PageModule { };

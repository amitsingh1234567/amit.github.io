import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OverviewNavbarComponent } from "./overview-navbar/overview-navbar.component"

import { CollapseModule } from "ngx-bootstrap/collapse";
import { DxVectorMapModule } from "devextreme-angular";
import { BsDropdownModule } from "ngx-bootstrap";
import { from } from 'rxjs';


@NgModule({
  imports: [
    CommonModule,
    CollapseModule.forRoot(),
    DxVectorMapModule,
    BsDropdownModule.forRoot()
  ],
  declarations: [
    OverviewNavbarComponent
  ],
  exports: [
    OverviewNavbarComponent
  ]
})
export class ComponentsOverviewModule { }

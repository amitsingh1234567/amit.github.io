import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup, FormControl } from "@angular/forms";
import { Service } from 'src/app/services/service';
import { ErrorService } from 'src/app/error/error-service';


@Component({
  selector: 'app-upload-post',
  templateUrl: './upload-post.component.html',
  styleUrls: ['./upload-post.component.scss']
})
export class UploadPostComponent implements OnInit {
  form: FormGroup;
  imageData: string;
  uploadType: string;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<UploadPostComponent>,
   private service: Service, private errService: ErrorService) {
    console.log(this.data)
    this.uploadType = this.data.uploadType;
  }

  ngOnInit(): void {
    this.form = new FormGroup({
      postTitle: new FormControl(null),
      image: new FormControl(null),
    });
    this.onFileSelect();
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onFileSelect(event?: Event, action?: string) {
    if (action == 'picImage') {
      this.data = { file: event };
    }
    const file = (this.data.file.target as HTMLInputElement).files[0];
    this.form.patchValue({ image: file });
    const reader = new FileReader();
    reader.onload = () => {
      this.imageData = reader.result as string;
    };
    reader.readAsDataURL(file);
  }

  onUploadPost() {
    const userId = localStorage.getItem('userId');
    if (this.data.uploadType == 'Create_Post') {
      this.service.uploadPost(this.form.value.postTitle, this.form.value.image, userId, 'createPost')
        .subscribe(res => {
          if (res.success) {
            this.dialogRef.close();
            this.service.setPostData(res.data);
          }else{
            this.errService.throwError(res.message)
          }
        });
    }
    if (this.data.uploadType == 'Profile_Photo') {
      this.service.uploadProfilePicture(this.form.value.image, userId, 'profilePhoto')
      .subscribe(res => {
        if (res.success) {
          this.dialogRef.close();
          this.service.setPostData(res.data);
        }else{
          this.errService.throwError(res.message)
        }
      })
    }
  }

}

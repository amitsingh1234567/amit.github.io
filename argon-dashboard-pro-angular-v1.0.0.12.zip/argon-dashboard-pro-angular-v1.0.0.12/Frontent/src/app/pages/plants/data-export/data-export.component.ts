import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';


@Component({
  selector: 'app-data-export',
  templateUrl: './data-export.component.html',
  styleUrls: ['./data-export.component.scss']
})
export class DataExportComponent implements OnInit {

  constructor(private spinner: NgxSpinnerService, ) { }

  ngOnInit() {

    this.spinner.show();
 
    setTimeout(() => {
      this.spinner.hide();
    }, 2000);
    

  }

}

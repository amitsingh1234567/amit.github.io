import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth-strategy/auth.service';
import { NgxSpinnerService } from "ngx-spinner";


@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.scss']
})
export class AnalyticsComponent implements OnInit {

  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();

  constructor(private spinner: NgxSpinnerService, public authService: AuthService) { 
    this.maxDate.setDate(this.maxDate.getDate() + 7);
    this.bsRangeValue = [this.bsValue, this.maxDate];
  }

  ngOnInit() {

    this.spinner.show();
 
    setTimeout(() => {
      this.spinner.hide();
    }, 2000);
    
  }

}

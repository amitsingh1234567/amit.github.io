import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ComponentModule } from './components/component.module'
import { from } from 'rxjs';
import { OutlineLayoutComponent } from './layouts/outline-layout/outline-layout.component';
import { UserModule } from './pages/user/user.module'
import { PageModule } from './pages/page.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './pages/user/auth-interceptor';
// import { BoldSpanPipe } from './pages/home/bold-span.pipe'

@NgModule({
  declarations: [
    AppComponent,
    OutlineLayoutComponent,
    // BoldSpanPipe
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    ComponentModule,
    HttpClientModule,
    UserModule,
    PageModule,
  ],
  providers: [{provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true}],
  bootstrap: [AppComponent]
})
export class AppModule { }

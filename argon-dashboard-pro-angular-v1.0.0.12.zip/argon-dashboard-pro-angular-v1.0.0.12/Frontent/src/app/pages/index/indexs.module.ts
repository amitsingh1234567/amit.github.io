import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ProgressbarModule } from "ngx-bootstrap/progressbar";
import { CollapseModule } from 'ngx-bootstrap/collapse';

import { RouterModule } from "@angular/router";
import { IndexsRoutes } from "./indexs.routing";
// import { MyserviceService } from '../';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(IndexsRoutes),
    ProgressbarModule.forRoot(),
    CollapseModule.forRoot()
  ],
  // providers:[MyserviceService]
  
})
export class IndexsModule {}

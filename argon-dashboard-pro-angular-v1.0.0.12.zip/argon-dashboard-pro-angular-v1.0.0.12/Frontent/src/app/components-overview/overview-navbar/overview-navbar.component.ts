import { Component, OnInit, ElementRef } from '@angular/core';
import { AuthService } from 'src/app/auth-strategy/auth.service';
import { MyserviceService } from 'src/app/myservice.service';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { ROUTES } from '../../components/sidebar/sidebar.component'
@Component({
  selector: 'app-overview-navbar',
  templateUrl: './overview-navbar.component.html',
  styleUrls: ['./overview-navbar.component.scss']
})
export class OverviewNavbarComponent implements OnInit {

  public plntname:any;

  constructor(private authService: AuthService, private myService: MyserviceService,
    
    ) { }
      
    

  ngOnInit() {
   
      console.log('Over-View-Navbar Component');
    console.log('OverView--Navbar Component');
    var id = localStorage.getItem('plant-Id')
        
    this.myService.allPlantName(id).subscribe(async data => {
    this.plntname = await data.plantname;
    console.log('OverView--Navbar Component');
    console.log(this.plntname[0].plantName);
    console.log('OverView--Navbar Component End');
    });
  }
  
  logout(){
      this.authService.logout();
  }


}

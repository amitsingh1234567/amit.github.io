import { OverviewComponent } from './../../overviews/overview/overview.component';
import { Component, OnInit } from "@angular/core";
import { Routes,Router } from "@angular/router";
import { AuthService } from '../../../auth-strategy/auth.service'
import { EmailValidator } from '@angular/forms';
import { MyserviceService } from '../../../myservice.service'


const overviewRoutes: Routes = [
  { path: 'overviews',  component: OverviewComponent }
];


@Component({
  selector: "app-login",
  templateUrl: "login.component.html"
})
export class LoginComponent implements OnInit {
  focus;
  focus1;
  email:string;
  password:string;
  emailError:string;
  passwordError: string;
  isAuthenticate: boolean;
  constructor(public router: Router, public _authService: AuthService, public myService: MyserviceService) {}

  ngOnInit() {
    
  }

  login = function() {
    this._authService.login(this.email, this.password)
    .subscribe(data => {
      if(data.success){
        this._authService.authToken(data.token, data.expiresIn, data.plantId)
        this._authService.logedIn(true);
        this.router.navigate(['/overviews/overview']);
        
      }else{
        this.emailError = data.email_err;
        this.passwordError = data.password_err;
      }
    })
  };
 
}

import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ComponentsModule } from "../../components/components.module";
import { FormsModule } from "@angular/forms";

import { BsDropdownModule } from "ngx-bootstrap";
import { ProgressbarModule } from "ngx-bootstrap/progressbar";
import { TooltipModule } from "ngx-bootstrap/tooltip";
import { PaginationModule } from "ngx-bootstrap/pagination";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";

import { NgxDatatableModule } from "@swimlane/ngx-datatable";
import { NgxPrintModule } from "ngx-print";
import { NgxSpinnerModule } from "ngx-spinner";

import { DashboardComponent } from "./dashboard/dashboard.component";
import { AlarmComponent } from './alarm/alarm.component';
import { InverterComponent } from './inverter/inverter.component';
import { WmsComponent } from './wms/wms.component';
import { InformationComponent } from './information/information.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { DataExportComponent } from './data-export/data-export.component';
import { MeterComponent } from './meter/meter.component';

import { RouterModule } from "@angular/router";
import { PlantsRoutes } from "./plants.routing";
import { from } from 'rxjs';

@NgModule({
  declarations: [DashboardComponent, AlarmComponent, InverterComponent, WmsComponent, InformationComponent, AnalyticsComponent, DataExportComponent, MeterComponent],
  imports: [
    CommonModule,
    ComponentsModule,
    BsDropdownModule.forRoot(),
    ProgressbarModule.forRoot(),
    TooltipModule.forRoot(),
    RouterModule.forChild(PlantsRoutes),
    NgxDatatableModule,
    PaginationModule.forRoot(),
    NgxPrintModule,
    FormsModule,
    BsDatepickerModule.forRoot(),
    NgxSpinnerModule
  ],
  exports: [DashboardComponent, AlarmComponent, InverterComponent, WmsComponent, InformationComponent,AnalyticsComponent, DataExportComponent, MeterComponent]
})
export class PlantsModule {}

import { Injectable } from '@angular/core';
import {Apollo} from 'apollo-angular';
import gql from 'graphql-tag';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  public plantId1: any;
  constructor(private http: HttpClient) { }

  plantName(id:any):Observable<any>{
   return this.http.get('http://localhost:3000/api/users/plantname/' + id)
  }

  allPlantName(id:any):Observable<any>{
      
    return this.http.get('http://localhost:3000/api/users/all-plantname/'+id)
  }

  plantId(id:any){
    this.plantId1 = id;
  }

  getPlantId(){
    return this.plantId1;
  }

}


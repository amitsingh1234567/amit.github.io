import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MaterialModule } from '../../material/material.module'
import { SigninComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component'
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from '@angular/router';
import { UserProfileComponent } from './user-profile/user-profile.component';

const components = [SigninComponent, SignupComponent, UserProfileComponent];

@NgModule({
  declarations: components,
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
  exports: components
})

export class UserModule { }

import { Routes } from "@angular/router";

import { OverviewComponent } from "./overview/overview.component"
import { AuthGuard } from '../../auth-strategy/auth.guard';



export const OverviewsRoutes: Routes = [
  {
    path: "",
    children: [
      {
        path: "overview",
        data:{value:true},
        component: OverviewComponent,
        canActivate: [AuthGuard]
      }
    ]
  }

];

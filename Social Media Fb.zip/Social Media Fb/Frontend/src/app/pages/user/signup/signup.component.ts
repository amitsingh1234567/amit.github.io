import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { Subscriber } from 'rxjs';
import { Service } from '../../../services/service';
import { ErrorService } from '../../../error/error-service'

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  signupForm: FormGroup;
  hide = true;

  constructor(private service: Service, private errorService: ErrorService) { }

  ngOnInit(): void {
    this.signupForm = new FormGroup({
      name: new FormControl(null, Validators.required),
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(null, Validators.required)
    })
  }

  onSubmit(){
   if(!this.signupForm.valid) return;
   let user = this.signupForm.value;
    this.service.signUp(user).subscribe(res => {
      if(res.success){
        this.errorService.throwError(res.message);
      }else{
        this.errorService.throwError(res.message);
      }
    })
  }

}

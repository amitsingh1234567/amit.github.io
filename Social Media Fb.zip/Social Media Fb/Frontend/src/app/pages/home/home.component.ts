import { AfterViewInit, Component, Directive, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Service } from 'src/app/services/service';
import { ElementRef } from '@angular/core';
import {cloneDeep} from 'lodash';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})

export class HomeComponent implements OnInit, AfterViewInit {

  totalComments: number;
  posts: any = [];
  replyToUserName: string;
  replyToUserName2: string;
  totalItems: number;
  currentPage: number = 1;
  smallnumPages: number = 0;
  comments: any = [];
  isViewReplyAction: boolean = false;
  constructor(private service: Service) { 
    this.service.getPostData().subscribe(res => {
      this.posts.unshift(res);
    })
  }

  ngOnInit(): void {
    let page = 1;
    let limit = 10;
    this.service.getPosts(page, limit).subscribe(res => {
      this.totalItems = res.totalItems;
      this.checkPost_Is_LikeOrNot(res);
    });
    console.log(this.comments)
  }
 
  getReplyArr(postId: string, commentId: string){
    const Post = this.comments.find(element => element.postId == postId);
    const Comment = Post.comments.find(element => element._id == commentId);
    const replyArr = Comment.reply;
    return { post: Post, comment: Comment, replyArr: replyArr };
  }

  viewReplyPagination(Page: number, Limit: number, postId: any, commentId: string){
    const data = this.getReplyArr(postId, commentId)
    const page = Page;
    const limit = Limit;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const result = data.replyArr.slice(startIndex, endIndex);
    return result;
  }

  viewMoreReply(postId: string, commentId: string){
    const data = this.getReplyArr(postId, commentId);
    const replyObj = data.post.reply.find(element => element.commentId == commentId);
    replyObj.viewReplyPage += 1;
    const result = this.viewReplyPagination(replyObj.viewReplyPage, 3, postId, commentId);
    result.forEach(element => {
      replyObj.replyArr.push(element);
    });
    console.log(this.comments)
    const totalReply = data.replyArr.length;
    const totalFetchedRply = replyObj.replyArr.length - replyObj.newReply;
    if(totalReply == totalFetchedRply){
      data.comment.viewMoreReply = false;
    }
  }
  
  viewReplyConfig(postId: string, commentId: string){
    const result = this.viewReplyPagination(1, 3, postId, commentId);
    const data = this.getReplyArr(postId, commentId);
    const Post = data.post;
    const replyObj = Post.reply.find(element => element.commentId == commentId);
    if(replyObj == undefined){
      Post.reply.push({viewReplyPage: 1, newReply: 0, commentId: commentId, replyArr: result});
      // this.isViewReplyAction = true;
      // Disable View Reply button
      data.comment.viewReply = false;
      data.comment.viewReply2 = false;
      data.comment.viewMoreReply = true;
    }else{
      result.forEach(element => {
        replyObj.replyArr.push(element);
      });
      // this.isViewReplyAction = true;
      // Disable View Reply button
      data.comment.viewReply = false;
      data.comment.viewReply2 = false;
      data.comment.viewMoreReply = true;
    }

    console.log(data.post)
    console.log(this.comments)
  }

  viewReply(postId: string, commentId: string){
    this.viewReplyConfig(postId, commentId);
  }

  viewRepl2(postId: string, commentId: string){
    this.viewReplyConfig(postId, commentId);
  }

  viewMoreComments(postId: string) {
   const Post = this.comments.find(element => element.postId == postId);
   Post.page += 1; 
   console.log(Post)
   this.commentPagination(postId, Post.page, 5);
  }

  commentPagination(postId: string, Page: number, Limit: number) {
    let commentLength;
    const Post = this.posts.find(element => element._id == postId);
    // If there is No comment
    if (Post.comments.length == 0) return { Post };
    const isCommentHere = this.comments.find(element => element.postId == postId);
    const page = Page;
    const limit = Limit;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const result = Post.comments.slice(startIndex, endIndex);
    result.forEach(element => {
      if(element.reply.length == 0){
        element.viewReply = false;
      }else{
        element.viewReply = true;
        element.viewReply2 = false;
      }
    });
      if (isCommentHere) {
        result.forEach(element => {
          isCommentHere.comments.push(element);
        });

      if(isCommentHere.newComment == undefined){
        commentLength = isCommentHere.comments.length;
      }else{
        commentLength = isCommentHere.comments.length - isCommentHere.newComment;
      }

      if (Post.comments.length == commentLength) {
        Post.isViewMoreAction = false;
      }
      } else {
        this.comments.push({ postId: Post._id, reply: [], comments: result });
        return { Post };
      }
  }

  showComments(postId: string) {
    let isDublicateClickEvent = false;
    this.comments.forEach(element => {
      if (element.postId == postId) {
        isDublicateClickEvent = true;
      }
    });

    if (!isDublicateClickEvent) {
      const data = this.commentPagination(postId, 1, 5);
      if(data.Post.comments.length != 0){
        const document = this.comments.find(element => element.postId == postId);
        document.page = 1;
      }
      if(data.Post.comments.length > 5){
        data.Post.isViewMoreAction = true;
      }else{
        data.Post.isViewMoreAction = false;
      }
    }
    console.log(this.comments)
  }

  pageChanged(event: any): void {
    console.log('Page changed to: ' + event.page);
    console.log('Number items per page: ' + event.itemsPerPage);
    this.service.getPosts(event.page, event.itemsPerPage).subscribe(res => {
      this.comments.splice(0, this.comments.length);
      this.posts.splice(0, this.posts.length);
      this.totalItems = res.totalItems;
      this.checkPost_Is_LikeOrNot(res);
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    })
  }

  checkPost_Is_LikeOrNot(res: any) {
    this.posts = res.data;
    res.data.forEach((element, index) => {
      element.isViewMoreAction = false;
      element.totalComment = element.comments.length;
      element.likes.forEach(item => {
        if (item._id == localStorage.getItem('userId')) {
          this.posts[index].isLike = true;
        } else {
          this.posts[index].isLike = false;
        }
        element.comments.forEach(comment => {
          comment.isReply = false;
          comment.isReply2 = false;
          comment.viewMoreReply = false;
        });
      });
    });
    console.log(this.posts)
  };

  likeToggle(postId: string, isLike: boolean) {
    let userId = localStorage.getItem('userId');
    if (isLike) {
      console.log('Unlike')
      this.posts.forEach(element => {
        if (element._id == postId) {
          this.service.unLike(postId, userId).subscribe(res => {
            console.log(res)
            element.isLike = false;
            element.likes = res.data.likes;
          })
        }
      });
    } else {
      console.log('Like')
      this.posts.forEach(element => {
        if (element._id == postId) {
          this.service.like(postId, userId).subscribe(res => {
            console.log(res)
            element.likes = res.data.likes;
            element.isLike = true;
          })
        }
      });
    }
  };

  onComment(postId: string, event: any, index: number) {
    if (event.target.value == '') return;
    const userId = localStorage.getItem('userId');
    this.service.comment(postId, userId, event.target.value).subscribe(res => {
      let element = this.posts[index];
      element.totalComment += 1;
      let isSamePost = false;
      this.comments.forEach(element => {
        if (element.postId == res.postId) {
          if(element.newComment == undefined){
            element.newComment = 1;
          }else{
            element.newComment += 1;
          }
          element.comments.push(res.data)
          isSamePost = true;
        }
      });

      if (!isSamePost) {
        if(element.comments.length != 0)
        element.isViewMoreAction = true;
        this.comments.push({ postId: res.postId, page: 0, reply: [], newComment: 1, comments: [res.data] })
      }
      event.target.value = '';
      console.log(this.comments)
    });
  };

  isReplyAction(postId: string, commentId: string, replyToUserName?: string) {
    const data = this.getReplyArr(postId, commentId);
    const replyObj = data.post.reply.find(element => element.commentId == commentId);
    const userId = localStorage.getItem('userId');
    if(userId == data.comment.commentedBy._id) return;

    if(replyToUserName == undefined){
      if(replyObj != undefined){
        replyObj.replyToUserName = null;
      }
      this.comments.forEach(element => {
        if(element.postId == postId){
          element.comments.forEach(item => {
            if(item._id == commentId){
              item.isReply = true;
              item.isReply2 = false;
            }
          });
        }
      });
    }else{
      replyObj.replyToUserName = `${replyToUserName} `;
      this.comments.forEach(element => {
        if(element.postId == postId){
          element.comments.forEach(item => {
            if(item._id == commentId){
              item.isReply = false;
              item.isReply2 = true;
            }
          });
        }
      });
    }
    console.log(this.comments)
  }

  onReply(postId: string,  commentId: string, event: any) {
    var userId = localStorage.getItem('userId');
    this.service.commentReply(postId, commentId, userId, event.target.value, 'Username').subscribe(res => {
      const data = this.getReplyArr(postId, commentId);
      const replyObj = data.post.reply.find(element => element.commentId == commentId);

      if(replyObj == undefined){
        // Check for View Reply event action occure or not
        data.comment.viewReply = false;
        data.comment.viewReply2 = true;
        if(data.comment.reply.length == 0)
        data.comment.viewReply2 = false;
        // Do reply in those comments which still not reply by anyone
        data.post.reply.push({viewReplyPage: 1, newReply: 1, commentId: commentId, replyArr: [res.data]});
        event.target.value = null;
      }else{
        // Do reply in those comments which already replyed by someone
        replyObj.replyArr.push(res.data);
        replyObj.newReply += 1;
        event.target.value = null;
      }

      console.log(data)
      console.log(commentId)
      console.log(this.comments)
    });

    return
    if (event.target.value == '') return;
    var text;
    var replyToUserName = this.replyToUserName2;
    let stringArr = event.target.value.split(" ");
    let userName = stringArr.splice(0, 1);
    let string = userName[0];
    let isReplyToUserName = string.slice(0, this.replyToUserName2.length);

    if (this.replyToUserName2 == isReplyToUserName) {
      let textFilter = string.slice(this.replyToUserName2.length);
      console.log(textFilter)
      stringArr.unshift(textFilter);
      if (stringArr[0] == "") {
        stringArr.splice(0, 1);
      }
      text = stringArr.join(" ");
    } else {
      console.log('***//*')
    }

  }



  // ngOnDestroy() {
  // }
  ngAfterViewInit() {
  }

}

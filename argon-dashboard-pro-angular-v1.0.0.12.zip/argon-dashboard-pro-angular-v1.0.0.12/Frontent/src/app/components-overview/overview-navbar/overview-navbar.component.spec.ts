import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverviewNavbarComponent } from './overview-navbar.component';

describe('OverviewNavbarComponent', () => {
  let component: OverviewNavbarComponent;
  let fixture: ComponentFixture<OverviewNavbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OverviewNavbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverviewNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

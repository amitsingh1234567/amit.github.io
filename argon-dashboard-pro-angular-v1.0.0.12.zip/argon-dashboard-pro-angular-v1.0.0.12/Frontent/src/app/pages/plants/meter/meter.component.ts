import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-meter',
  templateUrl: './meter.component.html',
  styleUrls: ['./meter.component.scss']
})
export class MeterComponent implements OnInit {

  constructor(private spinner: NgxSpinnerService,) { }

  ngOnInit() {
    
    this.spinner.show();
 
    setTimeout(() => {
      this.spinner.hide();
    }, 2000);

  }

}

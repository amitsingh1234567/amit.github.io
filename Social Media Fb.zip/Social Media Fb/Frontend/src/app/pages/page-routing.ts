// import { Routes } from "@angular/router";
// import { SigninComponent } from  './user/signin/signin.component';
// import { SignupComponent } from './user/signup/signup.component'

// export const PageRoutes: Routes = [ 
//     {
//         path: '',
//         component: SigninComponent
//     },
//     {
//         path: 'signup',
//         component: SignupComponent
//     }
// ];
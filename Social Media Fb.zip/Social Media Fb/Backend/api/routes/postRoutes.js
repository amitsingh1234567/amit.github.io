const express = require('express');
const router = express.Router();

// Require Authentication
const requireAuthentication = require('../../helpers/check-auth/check-auth');

// File upload storage
const fileStorage = require('../../helpers/storage');

// Post Controllers
const postControllers = require('../../controllers/postControllers');

router.post('/uploadPost', requireAuthentication, fileStorage, postControllers.uploadPost);
router.post('/uploadProfilePicture', requireAuthentication, fileStorage, postControllers.uploadProfilePicture);

// router.post('/createPost', postControllers.createPost);
router.get('/allPosts', postControllers.allPosts);

router.put('/like', postControllers.like);
router.put('/unlike', postControllers.unlike);
router.put('/comment', postControllers.comment);
router.put('/commentReply', postControllers.commentReply);

// Not in use
router.put('/reReply', postControllers.reReply);

router.get('/pagination', postControllers.pagination);

module.exports = router;
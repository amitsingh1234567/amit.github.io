import { Routes } from "@angular/router";


export const IndexsRoutes: Routes = [
 
];

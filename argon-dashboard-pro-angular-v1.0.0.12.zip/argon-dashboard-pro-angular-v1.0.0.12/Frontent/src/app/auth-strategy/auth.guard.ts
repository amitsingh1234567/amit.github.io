import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs'
import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { MyserviceService } from '../myservice.service';


@Injectable()
export class AuthGuard implements CanActivate {
    public isBolean: boolean
    public isAuth2 = true;
    constructor(public router: Router, private _authService: AuthService, private _myService: MyserviceService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
        var isAuth = this._authService.isAuthenticate();
        this._myService.plantId(route);
        console.log(route);
        if (!isAuth) {
            this.router.navigate(['/indexs/login']);
        }   
             
        isAuth = route.data.value;         
        return isAuth; 
    }
}

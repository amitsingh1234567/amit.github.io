import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../auth-strategy/auth.service'
import { Router, ActivatedRoute } from "@angular/router";
import { MyserviceService } from 'src/app/myservice.service';

export enum SelectionType {
  single = "single",
  multi = "multi",
  multiClick = "multiClick",
  cell = "cell",
  checkbox = "checkbox"
}

@Component({
  selector: 'app-information',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss']
})
export class OverviewComponent implements OnInit {
 public plantId: any;
 public plantId2: any;
 public datasets: any;
 public data: any;
 public salesChart;
 public clicked: boolean = true;
 public clicked1: boolean = false;
 
  constructor(public _authService: AuthService, private router: Router, private route: ActivatedRoute,
    private myService: MyserviceService
    ){
      this.temp = this.rows.map((prop, key) => {
        return {
          ...prop,
          id: key
        };
      });
  }

  ngOnInit() {
    console.log('Over-View Component');
  this.plantId = localStorage.getItem('plant-Id');
  this.plantId2 = JSON.parse(this.plantId);
  }

  plantIdClk(value, boolean){
    this._authService.setplnt_Id_Boolean_value(boolean);
    this._authService.routerId(value);
    this.router.navigate([`${value}/dashboard`]);
  }

  public updateOptions() {
    this.salesChart.data.datasets[0].data = this.data;
    this.salesChart.update();
  }

  entries: number = 10;
  selected: any[] = [];
  temp = [];
  activeRow: any;
  rows: any = [
    {
      name: "Inverter",
      position: "System Architect",
      office: "Edinburgh",
      age: "61",
      start: "2011/04/25",
      salary: "$320,800"
    },
    {
      name: "Garrett Winters",
      position: "Accountant",
      office: "Tokyo",
      age: "63",
      start: "2011/07/25",
      salary: "$170,750"
    },
    {
      name: "Ashton Cox",
      position: "Junior Technical Author",
      office: "San Francisco",
      age: "66",
      start: "2009/01/12",
      salary: "$86,000"
    },
    {
      name: "Cedric Kelly",
      position: "Senior Javascript Developer",
      office: "Edinburgh",
      age: "22",
      start: "2012/03/29",
      salary: "$433,060"
    }

  ];
  SelectionType = SelectionType;

  entriesChange($event) {
    this.entries = $event.target.value;
  }
  filterTable($event) {
    let val = $event.target.value;
    this.temp = this.rows.filter(function(d) {
      for (var key in d) {
        if (d[key].toLowerCase().indexOf(val) !== -1) {
          return true;
        }
      }
      return false;
    });
  }
  onSelect({ selected }) {
    this.selected.splice(0, this.selected.length);
    this.selected.push(...selected);
  }
  onActivate(event) {
    this.activeRow = event.row;
  }
}


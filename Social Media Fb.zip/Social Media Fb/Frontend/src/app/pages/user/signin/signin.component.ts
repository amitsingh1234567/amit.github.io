import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { Service } from '../../../services/service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {
  signInForm: FormGroup;
  hide = true;
  constructor(private service: Service) { }

  ngOnInit(): void {
    this.signInForm = new FormGroup({
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(null, Validators.required)
    })
  }

  onSubmit(){
    if(!this.signInForm.valid) return;
    let userCredential = this.signInForm.value;
    this.service.signIn(userCredential)
    // .subscribe(res => {
    //   this.errorService.throwError(res.message)
    // })
  }
  
}

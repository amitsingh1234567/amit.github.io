import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Service } from 'src/app/services/service';

@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.scss']
})

export class AllUsersComponent implements OnInit {
  users: any;
  constructor(private service: Service, private router: Router) { }

  ngOnInit(): void {
    this.service.users().subscribe(res => {
      console.log(res)
      this.users = res.data;
      let loginID = localStorage.getItem('userId')
      // this.users = res.user.filter((value, key) => {
      //   return value._id != loginID;
      // })
    })
  }

  viewProfile(userId: string){
    this.router.navigate([`/user/${userId}`]);
  }

}

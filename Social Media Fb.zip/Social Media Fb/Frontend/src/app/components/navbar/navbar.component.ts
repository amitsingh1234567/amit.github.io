import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Service } from 'src/app/services/service';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { UploadPostComponent } from '../../pages/upload-post/upload-post.component'

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  user: any;
  profile_photo: any;
  constructor(private router: Router, private service: Service, public dialog: MatDialog) {};

  ngOnInit(): void {
    this.service.getUser().subscribe(res => {
      this.user = res
      this.profile_photo = res.profilePic
      console.log(this.user)
    })
  }
  openDialog(event: Event, uploadType: string) {
    let width;
    let Height;
    if(uploadType == 'Create_Post'){
      width = '520px';
      Height= '590px';
    }

    if(uploadType == 'Profile_Photo'){
      width = '500px';
      Height= '500px';
    }

    this.dialog.open(UploadPostComponent, {
      data: {
        file: event,
        uploadType: uploadType
      },
      width: width,
      height: Height
    });
  }

  onImagePicked(event: Event){
    this.openDialog(event, 'Create_Post');
  }

  onImagePicked2(event: Event){
    this.openDialog(event, 'Profile_Photo');
  }

  userProfile(){
    // this.service.getUser();
    // this.router.navigate([`/user/${this.user._id}`]);
    // console.log(this.user);
  }
  uploadProfile(){
    console.log('******--')
  }

  deleteAccount(){
   let answer = window.confirm('Are you sure you want to delete your Account?')
   if(answer){
     console.log('******7')
   }else{
     console.log('******8')

   }
  }

}

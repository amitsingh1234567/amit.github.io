import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-overview-layout',
  templateUrl: './overview-layout.component.html',
  styleUrls: ['./overview-layout.component.scss']
})
export class OverviewLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

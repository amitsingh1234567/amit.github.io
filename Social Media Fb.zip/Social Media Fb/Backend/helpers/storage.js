const multer = require('multer');

const MIME_TYPE_MAP = {
    'image/png': 'png',
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
};

const diskStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        let location;
        if(req.body.uploadType == 'createPost'){
            location = 'images';
        }
        if(req.body.uploadType == 'profilePhoto'){
            location = 'profileImages';
        }
        cb(null, location);
    },
    filename: (req, file, cb) => {
        const fileName = file.originalname;
        const ext = MIME_TYPE_MAP[file.mimetype];
        cb(null, `${fileName}-${Date.now()}.${ext}`);
    }
});

const storage = multer({storage: diskStorage}).single('images');


// const MIME_TYPE_MAP = {
//     'image/png': 'png',
//     'image/jpeg': 'jpg',
//     'image/jpg': 'jpg',
// };

// const diskStorage = multer.diskStorage({
//     destination: (req, file, cb) => {
//         cb(null, 'images');
//     },
//     filename: (req, file, cb) => {
//         const fileName = file.originalname;
//         const ext = MIME_TYPE_MAP[file.mimetype];
//         cb(null, `${fileName}-${Date.now()}.${ext}`);
//     }
// });

// const storage = multer({storage: diskStorage}).single('images');

module.exports = storage;

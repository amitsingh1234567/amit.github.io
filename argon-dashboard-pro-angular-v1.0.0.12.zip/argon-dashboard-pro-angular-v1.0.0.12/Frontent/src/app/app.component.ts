import { Component, OnInit } from "@angular/core";
import { Router, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { AuthService } from './auth-strategy/auth.service';
import { SocketService } from './socket/socket.service';
// import * as io from 'socket.io-client'
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
  
})
export class AppComponent implements OnInit {
  
  ngOnInit(): void {
    this.socketService.listner();
    this._authService.autoAuthUser();
    // const socket = io('http://localhost:3000');
    // socket.on('hello', data => {
    //   console.log(data);
    // })
    
    // socket.emit('getData', {msg: 'From Client...'});
    

    // this.socketService.listen('test event').subscribe(data => {
    //   console.log(data)
    // })
    
  }
  constructor(private router: Router, private spinner: NgxSpinnerService, public _authService: AuthService, public socketService:SocketService) {
     this.router.events.subscribe((event: Event) => {
         if (event instanceof NavigationStart) {
             // Show loading indicator
             window.scrollTo(0,0);
         }

         if (event instanceof NavigationEnd) {
             // Hide loading indicator
         }

         if (event instanceof NavigationError) {
             // Hide loading indicator

             // Present error to user
             console.log(event.error);
         }
     });
   }
}

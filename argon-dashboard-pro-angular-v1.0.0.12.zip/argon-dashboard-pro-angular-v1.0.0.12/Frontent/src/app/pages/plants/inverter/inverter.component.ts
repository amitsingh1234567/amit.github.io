import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-inverter',
  templateUrl: './inverter.component.html',
  styleUrls: ['./inverter.component.scss']
})
export class InverterComponent implements OnInit {

  constructor(private spinner: NgxSpinnerService,) { }

  ngOnInit() {
    
    this.spinner.show();
 
    setTimeout(() => {
      this.spinner.hide();
    }, 2000);

  }

}
